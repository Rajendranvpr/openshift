package com.redhat.coolstore.inventory.service;

import java.io.StringReader;
import java.util.Optional;
import javax.annotation.PostConstruct;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.json.Json;
import javax.json.JsonObject;
import javax.ws.rs.ServiceUnavailableException;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.redhat.coolstore.inventory.tracing.InvocationBuilderCarrier;
import io.opentracing.Span;
import io.opentracing.Tracer;
import io.opentracing.propagation.Format;
import io.opentracing.util.GlobalTracer;
import org.jboss.resteasy.client.jaxrs.ResteasyClientBuilder;
import org.wildfly.swarm.spi.runtime.annotations.ConfigurationValue;

@ApplicationScoped
public class StoreStatusService {

    private WebTarget storeService;

    @Inject
    @ConfigurationValue("store.service.url")
    private String storeUrl;

    public String storeStatus(String store) {

        Tracer tracer = GlobalTracer.get();
        Optional<Span> activeSpan = Optional.ofNullable(tracer.activeSpan());

        Invocation.Builder builder = storeService.resolveTemplate("store", store).request(MediaType.APPLICATION_JSON);

        activeSpan.map(Span::context).ifPresent(s -> tracer.inject(s, Format.Builtin.HTTP_HEADERS, new InvocationBuilderCarrier(builder)));

        Response response = builder.get();
        if (response.getStatus() == 200) {
            JsonObject jsonResponse = Json.createReader(new StringReader(response.readEntity(String.class))).readObject();
            return jsonResponse.getString("status");
        } else if (response.getStatus() == 404) {
            return null;
        } else {
            throw new ServiceUnavailableException();
        }
    }


    @PostConstruct
    public void init() {
        storeService = ((ResteasyClientBuilder)ClientBuilder.newBuilder())
                .connectionPoolSize(10).build().target(storeUrl).path("store/status").path("{store}");
    }

}
