package com.redhat.coolstore.inventory.tracing;

import java.util.Iterator;
import java.util.Map;
import javax.ws.rs.client.Invocation;

import io.opentracing.propagation.TextMap;

public class InvocationBuilderCarrier implements TextMap {

    final Invocation.Builder invocationBuilder;

    public InvocationBuilderCarrier(Invocation.Builder invocationBuilder) {
        this.invocationBuilder = invocationBuilder;
    }

    @Override
    public Iterator<Map.Entry<String, String>> iterator() {
        throw new UnsupportedOperationException("Should be used only with tracer#inject()");
    }

    @Override
    public void put(String key, String value) {
        invocationBuilder.header(key, value);
    }
}
