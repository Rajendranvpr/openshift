Coolstore Catalog service for Appmod Microservices Advanced course.

Implementation: Vert.x + MongoDB