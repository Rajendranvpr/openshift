package com.redhat.coolstore.inventory.rest;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.NotFoundException;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.netflix.hystrix.HystrixCommand;
import com.netflix.hystrix.HystrixCommandGroupKey;
import com.netflix.hystrix.HystrixCommandProperties;
import com.netflix.hystrix.exception.HystrixRuntimeException;
import com.redhat.coolstore.inventory.model.Inventory;
import com.redhat.coolstore.inventory.service.InventoryService;
import com.redhat.coolstore.inventory.service.StoreStatusService;
import org.wildfly.swarm.spi.runtime.annotations.ConfigurationValue;

@Path("/inventory")
@RequestScoped
public class InventoryResource {

    @Inject
    private InventoryService inventoryService;

    @Inject
    private StoreStatusService storeStatusService;

    @Inject
    @ConfigurationValue("hystrix.inventory.groupKey")
    private String hystrixGroupKey;

    @Inject
    @ConfigurationValue("hystrix.inventory.circuitBreaker.requestVolumeThreshold")
    private int hystrixCircuitBreakerRequestVolumeThreshold;


    @GET
    @Path("/{itemId}")
    @Produces(MediaType.APPLICATION_JSON)
    public Inventory getInventory(@PathParam("itemId") String itemId, @DefaultValue("false") @QueryParam("storeStatus") boolean storeStatus) {
        try {
            Inventory inventory = new GetInventoryCommand(itemId).execute();
            if (inventory == null) {
                throw new NotFoundException();
            } else {
                if (storeStatus) {
                    String status = storeStatusService.storeStatus(inventory.getLocation());
                    inventory.setLocation(inventory.getLocation() + " [" + status + "]");
                }
                return inventory;
            }
        } catch (HystrixRuntimeException e) {
            System.err.println(e);
            throw new WebApplicationException(Response.Status.SERVICE_UNAVAILABLE);
        }

    }

    class GetInventoryCommand extends HystrixCommand<Inventory> {

        private String itemId;

        public GetInventoryCommand(String itemId) {
            super(Setter.withGroupKey(HystrixCommandGroupKey.Factory.asKey(hystrixGroupKey))
                    .andCommandPropertiesDefaults(HystrixCommandProperties.Setter().
                            withCircuitBreakerRequestVolumeThreshold(hystrixCircuitBreakerRequestVolumeThreshold)));
            this.itemId = itemId;
        }

        @Override
        protected Inventory run() throws Exception {
            return inventoryService.getInventory(itemId);
        }
    }
}

