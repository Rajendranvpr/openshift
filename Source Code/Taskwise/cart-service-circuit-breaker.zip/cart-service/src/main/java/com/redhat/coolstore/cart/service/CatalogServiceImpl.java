package com.redhat.coolstore.cart.service;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.redhat.coolstore.cart.model.Product;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.redhat.coolstore.cart.model.Product;

@Component
public class CatalogServiceImpl implements CatalogService {

    @Value("${catalog.service.url}")
    private String catalogServiceUrl;

    @Override
    @HystrixCommand(groupKey = "CartService", commandKey = "CatalogService", fallbackMethod = "getFallbackProduct")
    public Product getProduct(String itemId) {
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<Product> entity;
        try {
            entity = restTemplate.getForEntity(catalogServiceUrl + "/product/" + itemId, Product.class);
            return entity.getBody();
        } catch (HttpClientErrorException e) {
            e.printStackTrace();
            
            if (e.getRawStatusCode() == 404) {
                return null;
            } else {
                throw e;
            }
        }
    }

    protected Product getFallbackProduct(String itemId) {
       return null;
    }


}
