package com.redhat.coolstore.cart.service;

import com.redhat.coolstore.cart.model.ShoppingCart;

public interface PriceCalculationService {

    public void priceShoppingCart(ShoppingCart sc);

}
