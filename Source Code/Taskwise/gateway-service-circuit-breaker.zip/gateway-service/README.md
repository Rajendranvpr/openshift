Coolstore Gateway service for Appmod Microservices Advanced course.

Implementation: Camel on Spring Boot