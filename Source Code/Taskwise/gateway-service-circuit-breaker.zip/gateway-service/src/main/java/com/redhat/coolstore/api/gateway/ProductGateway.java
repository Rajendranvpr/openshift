package com.redhat.coolstore.api.gateway;

import java.util.Collections;

import org.apache.camel.Exchange;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.http4.HttpMethods;
import org.apache.camel.component.jackson.JacksonDataFormat;
import org.apache.camel.component.jackson.ListJacksonDataFormat;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.apache.camel.model.rest.RestBindingMode;
import org.apache.camel.processor.aggregate.AggregationStrategy;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;

import com.redhat.coolstore.api.gateway.model.Inventory;
import com.redhat.coolstore.api.gateway.model.Product;

@Component
public class ProductGateway extends RouteBuilder {

    @Value("${hystrix.products.executionTimeout}")
    private int hystrixProductsExecutionTimeout;

    @Value("${hystrix.products.groupKey}")
    private String hystrixProductsGroupKey;

    @Value("${hystrix.products.circuitBreakerEnabled}")
    private boolean hystrixProductsCircuitBreakerEnabled;

    @Value("${hystrix.inventory.executionTimeout}")
    private int hystrixInventoryExecutionTimeout;

    @Value("${hystrix.inventory.groupKey}")
    private String hystrixInventoryGroupKey;

    @Value("${hystrix.inventory.circuitBreakerEnabled}")
    private boolean hystrixInventoryCircuitBreakerEnabled;

    @Override
    public void configure() throws Exception {

        JacksonDataFormat productFormatter = new ListJacksonDataFormat();
        productFormatter.setUnmarshalType(Product.class);

        restConfiguration("product")
            .component("servlet")
            .bindingMode(RestBindingMode.json)
            .enableCORS(true);

        rest("/products/").description("Product Catalog Service")
            .produces(MediaType.APPLICATION_JSON_VALUE)

        .get("/").description("Get Product Catalog").outType(Product.class)
            .route().id("productRoute")
                .hystrix().id("Product Service")
                    .hystrixConfiguration()
                        .executionTimeoutInMilliseconds(hystrixProductsExecutionTimeout)
                        .groupKey(hystrixProductsGroupKey)
                        .circuitBreakerEnabled(hystrixProductsCircuitBreakerEnabled)
                    .end()
                    .setBody(simple("null"))
                    .removeHeaders("CamelHttp*")
                    .setHeader(Exchange.CONTENT_TYPE, simple(MediaType.APPLICATION_JSON_VALUE))
                    .setHeader(Exchange.HTTP_METHOD, HttpMethods.GET)
                    .setHeader(Exchange.HTTP_PATH, simple("products"))
                    .setHeader(Exchange.HTTP_URI, simple("{{catalog.service.url}}"))
                    .to("http4://DUMMY")
                    .unmarshal(productFormatter)
                .onFallback()
                    .to("direct:productFallback")
                    .stop()
                .end()
            .split(body()).parallelProcessing()
                .enrich("direct:inventory", new InventoryEnricher())
            .end()
        .endRest();

       from("direct:inventory")
            .id("inventoryRoute")
            .setHeader("itemId", simple("${body.itemId}"))
            .hystrix().id("Inventory Service")
                .hystrixConfiguration()
                    .executionTimeoutInMilliseconds(hystrixInventoryExecutionTimeout)
                    .groupKey(hystrixInventoryGroupKey)
                    .circuitBreakerEnabled(hystrixInventoryCircuitBreakerEnabled)
                .end()
                .setBody(simple("null"))
                .removeHeaders("CamelHttp*")
                .setHeader(Exchange.CONTENT_TYPE, simple(MediaType.APPLICATION_JSON_VALUE))
                .setHeader(Exchange.HTTP_METHOD, HttpMethods.GET)
                .setHeader(Exchange.HTTP_PATH, simple("inventory/${header.itemId}"))
                .setHeader(Exchange.HTTP_URI, simple("{{inventory.service.url}}"))
                .to("http4://DUMMY1")
            .onFallback()
                .to("direct:inventoryFallback")
            .end()
            .setHeader("CamelJacksonUnmarshalType", simple(Inventory.class.getName()))
            .unmarshal().json(JsonLibrary.Jackson, Inventory.class);

        from("direct:productFallback")
            .id("ProductFallbackRoute")
            .transform()
            .constant(Collections.singletonList(getFallbackProduct()));

        from("direct:inventoryFallback")
            .id("inventoryFallbackRoute")
            .transform()
            .constant(getFallbackInventory())
            .marshal().json(JsonLibrary.Jackson, Inventory.class);

    }

    private Product getFallbackProduct() {
        Product product = new Product();
        product.setItemId("0");
        product.setName("Unavailable Product");
        product.setDesc("Unavailable Product");
        product.setPrice(0);
        product.setAvailability(getFallbackInventory());
        return product;
    }

    private Inventory getFallbackInventory() {
        Inventory inventory = new Inventory();
        inventory.setItemId("0");
        inventory.setQuantity(0);
        inventory.setLocation("Local Store");
        inventory.setLink("http://developers.redhat.com");
        return inventory;
    }

    private class InventoryEnricher implements AggregationStrategy {
        @Override
        public Exchange aggregate(Exchange original, Exchange resource) {

            // Add the discovered availability to the product and set it back
            Product p = original.getIn().getBody(Product.class);
            Inventory i = resource.getIn().getBody(Inventory.class);
            p.setAvailability(i);
            original.getOut().setBody(p);
            return original;
        }
    }

}
