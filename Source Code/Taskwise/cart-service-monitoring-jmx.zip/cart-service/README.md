Coolstore Shopping Cart service for Appmod Microservices Advanced course.

Implementation: Spring Boot
