package com.redhat.coolstore.cart.rest;

import javax.annotation.PostConstruct;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.codahale.metrics.MetricRegistry;
import com.codahale.metrics.Timer;
import com.redhat.coolstore.cart.model.ShoppingCart;
import com.redhat.coolstore.cart.service.ShoppingCartService;

@Path("/cart")
@Component
public class CartEndpoint {

    private static final Logger LOG = LoggerFactory.getLogger(CartEndpoint.class);

    @Autowired
    private ShoppingCartService shoppingCartService;
    
    @Autowired
	private MetricRegistry metricRegistry;
    
    private Timer getCartTimer;

	private Timer addToCartTimer;

	private Timer checkoutCartTimer;
	
	@PostConstruct
	public void init() {
		getCartTimer = metricRegistry.timer("CartService_getCart");
		addToCartTimer = metricRegistry.timer("CartService_addToCart");
		checkoutCartTimer = metricRegistry.timer("CartService_checkoutCart");
	}
	@GET
	@Path("/{cartId}")
	@Produces(MediaType.APPLICATION_JSON)
	public ShoppingCart getCart(@PathParam("cartId") String cartId) {
		Timer.Context timer = getCartTimer.time();
		try {
			return shoppingCartService.getShoppingCart(cartId);
		} finally {
			timer.stop();
		}
	}

	@POST
	@Path("/{cartId}/{itemId}/{quantity}")
	@Produces(MediaType.APPLICATION_JSON)
	public ShoppingCart add(@PathParam("cartId") String cartId, @PathParam("itemId") String itemId, @PathParam("quantity") int quantity) throws Exception {
		Timer.Context timer = addToCartTimer.time();
		try {
			return shoppingCartService.addToCart(cartId, itemId, quantity);
		} catch (Exception e) {
			e.printStackTrace();
			throw new WebApplicationException(Response.Status.SERVICE_UNAVAILABLE);
		}
		finally {
			timer.stop();
		}
	}

	@DELETE
	@Path("/{cartId}/{itemId}/{quantity}")
	@Produces(MediaType.APPLICATION_JSON)
	public ShoppingCart delete(@PathParam("cartId") String cartId, @PathParam("itemId") String itemId, @PathParam("quantity") int quantity) throws Exception {
		Timer.Context timer = addToCartTimer.time();
		try {
			return shoppingCartService.removeFromCart(cartId, itemId, quantity);
		}finally {
			timer.stop();
		}
	}

	@POST
	@Path("/checkout/{cartId}")
	@Produces(MediaType.APPLICATION_JSON)
	public ShoppingCart checkout(@PathParam("cartId") String cartId) {
		Timer.Context timer = checkoutCartTimer.time();
		try {
			return shoppingCartService.checkoutShoppingCart(cartId);
		}finally {
			timer.stop();
		}
	}

}
