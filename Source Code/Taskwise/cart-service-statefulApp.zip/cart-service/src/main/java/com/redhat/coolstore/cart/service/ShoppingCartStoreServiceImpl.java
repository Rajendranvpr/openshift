package com.redhat.coolstore.cart.service;

import org.infinispan.client.hotrod.RemoteCacheManager;
import org.infinispan.commons.api.BasicCache;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.redhat.coolstore.cart.model.ShoppingCart;

@Component
public class ShoppingCartStoreServiceImpl implements ShoppingCartStoreService {

	@Autowired
	private RemoteCacheManager cacheManager;

	@Value("${cart.cache.name}")
	private String cacheName;


	@Override
	public ShoppingCart get(String id) {
		BasicCache<String, ShoppingCart> cache = cacheManager.getCache(cacheName);
		return cache.get(id);
	}

	@Override
	public void put(String id, ShoppingCart shoppingCart) {
		if (shoppingCart == null || id == null) {
			return;
		}
		BasicCache<String, ShoppingCart> cache = cacheManager.getCache(cacheName);
		cache.put(id, shoppingCart);

	}


}
