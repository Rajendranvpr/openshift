package com.redhat.coolstore.cart.cache;

import java.util.Optional;

import org.infinispan.client.hotrod.RemoteCacheManager;
import org.infinispan.client.hotrod.configuration.ConfigurationBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RemoteCacheContainerProvider {

	@Autowired
	private InfinispanRemoteConfigurationProperties infinispanProperties;

	@Bean
	public RemoteCacheManager remoteCacheManager() {
		ConfigurationBuilder builder = new ConfigurationBuilder();
		builder.addServers(infinispanProperties.getServerList());
		Optional.ofNullable(infinispanProperties.getConnectTimeout()).map(v -> builder.connectionTimeout(v));
		Optional.ofNullable(infinispanProperties.getMaxRetries()).map(v -> builder.maxRetries(v));
		Optional.ofNullable(infinispanProperties.getSocketTimeout()).map(v -> builder.socketTimeout(v));
		return new RemoteCacheManager(builder.build());
	}



}
