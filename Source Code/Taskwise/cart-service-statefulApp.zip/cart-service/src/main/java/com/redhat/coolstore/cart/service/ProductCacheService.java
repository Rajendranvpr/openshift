package com.redhat.coolstore.cart.service;

import com.redhat.coolstore.cart.model.Product;

public interface ProductCacheService {

	Product get(String id);

	void put(String id, Product product);

}
