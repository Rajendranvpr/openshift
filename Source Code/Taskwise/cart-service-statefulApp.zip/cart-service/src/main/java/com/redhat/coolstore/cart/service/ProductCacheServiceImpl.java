package com.redhat.coolstore.cart.service;

import java.util.concurrent.TimeUnit;

import org.infinispan.client.hotrod.RemoteCacheManager;
import org.infinispan.commons.api.BasicCache;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.redhat.coolstore.cart.model.Product;

@Component
public class ProductCacheServiceImpl implements ProductCacheService{

	@Autowired
	private RemoteCacheManager cacheManager;
	
	@Value("${product.cache.ttl.seconds}")
    private int ttlSeconds;

	@Value("${product.cache.name}")
	private String cacheName;

	@Override
	public Product get(String id) {
		BasicCache<String, Product> cache = cacheManager.getCache(cacheName);
		return cache.get(id);
	}

	@Override
	public void put(String id, Product product) {
		if (product == null || id == null) {
			return;
		}
		BasicCache<String, Product> cache = cacheManager.getCache(cacheName);
		cache.put(id, product,ttlSeconds,TimeUnit.SECONDS);
	}

}
