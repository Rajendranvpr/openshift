Coolstore Store service for Appmod Microservices Advanced course.

Implementation: WildFly Swarm
