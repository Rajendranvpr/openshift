package com.redhat.coolstore.cart.rest;

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.core.Response;

import org.springframework.stereotype.Component;

import io.prometheus.client.CollectorRegistry;
import io.prometheus.client.exporter.common.TextFormat;


@Component
@Path("/metrics")
public class PrometheusEndpoint {
	
	@GET
	@Path("/")
	public Response export() {

		String result = writeRegistry();
		return Response.ok(result, TextFormat.CONTENT_TYPE_004).build();

	}
	
	private String writeRegistry() {
		try {
			Writer writer = new StringWriter();
			TextFormat.write004(writer, CollectorRegistry.defaultRegistry.metricFamilySamples());
			return writer.toString();
		} catch (IOException e) {
			// This actually never happens since StringWriter::write() doesn't throw any IOException
			throw new RuntimeException("Writing metrics failed", e);
		}
	}

}