package com.redhat.coolstore.inventory.service;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Future;

import javax.enterprise.inject.Specializes;

@Specializes
public class MockStoreStatusService extends StoreStatusService {

    @Override
    public Future<String> storeStatus(String store) {
        return  CompletableFuture.completedFuture("MOCK");
    }
}
