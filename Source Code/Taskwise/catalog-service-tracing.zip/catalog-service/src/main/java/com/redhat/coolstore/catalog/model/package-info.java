@io.vertx.codegen.annotations.ModuleGen(groupPackage = "com.redhat.coolstore.catalog.model", name = "coolstore-catalog-model")
package com.redhat.coolstore.catalog.model;

