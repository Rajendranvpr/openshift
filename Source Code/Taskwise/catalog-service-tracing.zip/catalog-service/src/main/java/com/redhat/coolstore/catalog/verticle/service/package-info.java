@io.vertx.codegen.annotations.ModuleGen(groupPackage = "com.redhat.coolstore.catalog.verticle.service", name = "coolstore-catalog-service")
package com.redhat.coolstore.catalog.verticle.service;

