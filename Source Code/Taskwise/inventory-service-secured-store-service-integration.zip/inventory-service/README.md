Coolstore Inventory service for Appmod Microservices Advanced course.

Implementation: WildFly Swarm + PostgreSQL
