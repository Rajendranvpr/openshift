insert into PRODUCT_INVENTORY (itemId, link, location, quantity) values ('123456', 'link', 'location', 99)
