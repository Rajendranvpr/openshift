package com.redhat.coolstore.cart.service;

import org.keycloak.adapters.springsecurity.client.KeycloakClientRequestFactory;
import org.keycloak.adapters.springsecurity.client.KeycloakRestTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.redhat.coolstore.cart.model.Product;

@Component
public class CatalogServiceImpl implements CatalogService {

    @Value("${catalog.service.url}")
    private String catalogServiceUrl;

    @Autowired
    private KeycloakClientRequestFactory clientRequestFactory;

    @Override
    public Product getProduct(String itemId) {
        RestTemplate restTemplate = new KeycloakRestTemplate(clientRequestFactory);
        ResponseEntity<Product> entity;
        try {
            entity = restTemplate.getForEntity(catalogServiceUrl + "/product/" + itemId, Product.class);
            return entity.getBody();
        } catch (HttpClientErrorException e) {
            e.printStackTrace();
            
            if (e.getRawStatusCode() == 404) {
                return null;
            } else {
                throw e;
            }
        }
    }

}
