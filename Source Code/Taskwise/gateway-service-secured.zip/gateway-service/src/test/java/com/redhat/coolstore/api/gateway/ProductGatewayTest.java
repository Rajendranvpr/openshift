package com.redhat.coolstore.api.gateway;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.getRequestedFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static com.github.tomakehurst.wiremock.client.WireMock.urlMatching;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.Security;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.builder.AdviceWithRouteBuilder;
import org.apache.camel.builder.NotifyBuilder;
import org.apache.http.HttpStatus;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.util.io.pem.PemObject;
import org.bouncycastle.util.io.pem.PemReader;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.keycloak.jose.jws.Algorithm;
import org.keycloak.jose.jws.JWSBuilder;
import org.keycloak.representations.AccessToken;
import org.keycloak.util.TokenUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.tomakehurst.wiremock.client.WireMock;
import com.github.tomakehurst.wiremock.core.WireMockConfiguration;
import com.github.tomakehurst.wiremock.junit.WireMockRule;
import com.redhat.coolstore.api.gateway.model.Inventory;
import com.redhat.coolstore.api.gateway.model.Product;

@ActiveProfiles("test")
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
public class ProductGatewayTest {

    @Autowired
    private TestRestTemplate restTemplate;

    @Autowired
    private CamelContext camelContext;

    @Rule
    public WireMockRule catalogServiceMock = new WireMockRule(WireMockConfiguration.wireMockConfig().dynamicPort());

    @Rule
    public WireMockRule inventoryServiceMock = new WireMockRule(WireMockConfiguration.wireMockConfig().dynamicPort());

    @Test
    @DirtiesContext
    public void getProductCatalogEnrichedWithInventory() throws Exception {

        List<Product> products = new ArrayList<Product>();
        Product p1 = new Product();
        p1.setItemId("p1");
        p1.setDesc("description");
        p1.setName("product1");
        p1.setPrice(10.0);
        products.add(p1);

        Product p2 = new Product();
        p2.setItemId("p2");
        p2.setDesc("description");
        p2.setName("product2");
        p2.setPrice(10.0);
        products.add(p2);

        Inventory inventory1 = new Inventory();
        inventory1.setItemId("p1");
        inventory1.setQuantity(1);
        inventory1.setLocation("Local Store");
        inventory1.setLink("http://developers.redhat/com");

        Inventory inventory2 = new Inventory();
        inventory2.setItemId("p2");
        inventory2.setQuantity(2);
        inventory2.setLocation("Local Store");
        inventory2.setLink("http://developers.redhat/com");

        ObjectMapper mapper = new ObjectMapper();
        String productResponseStr = mapper.writeValueAsString(products);
        String inventory1ResponseStr = mapper.writeValueAsString(inventory1);
        String inventory2ResponseStr = mapper.writeValueAsString(inventory2);

        String authHeader = "Bearer " + getValidAccessToken("coolstore");

        catalogServiceMock.stubFor(get(urlMatching("/products"))
                .withHeader("Authorization", WireMock.equalTo(authHeader))
                .willReturn(aResponse()
                .withStatus(200).withHeader("Content-Type", "application/json")
                .withBody(productResponseStr)));

        inventoryServiceMock.stubFor(get(urlMatching("/inventory/p1"))
                .withHeader("Authorization", WireMock.equalTo(authHeader))
                .willReturn(aResponse()
                .withStatus(200).withHeader("Content-Type", "application/json")
                .withBody(inventory1ResponseStr)));

        inventoryServiceMock.stubFor(get(urlMatching("/inventory/p2"))
                .withHeader("Authorization", WireMock.equalTo(authHeader))
                .willReturn(aResponse()
                .withStatus(200).withHeader("Content-Type", "application/json")
                .withBody(inventory2ResponseStr)));

        NotifyBuilder notify = new NotifyBuilder(camelContext).fromRoute("productRoute").whenDone(1).create();

        adviceCamelContext();
        HttpHeaders headers = new HttpHeaders();
        headers.add(HttpHeaders.AUTHORIZATION, authHeader);
        ResponseEntity<String> response = restTemplate.exchange("/api/products", HttpMethod.GET, new HttpEntity<>(headers), String.class);

        assertThat(notify.matches(10, TimeUnit.SECONDS), is(true));

        assertThat(response.getStatusCodeValue(), equalTo(HttpStatus.SC_OK));

        JsonNode node = new ObjectMapper(new JsonFactory()).readTree(response.getBody());
        assertThat(node.get(0).get("itemId").asText(), equalTo("p1"));
        assertThat(node.get(0).get("availability").get("itemId").asText(), equalTo("p1"));
        assertThat(node.get(0).get("availability").get("quantity").asInt(), equalTo(1));
        assertThat(node.get(1).get("itemId").asText(), equalTo("p2"));
        assertThat(node.get(1).get("availability").get("itemId").asText(), equalTo("p2"));
        assertThat(node.get(1).get("availability").get("quantity").asInt(), equalTo(2));
        assertCorsHeaders(response);
        catalogServiceMock.verify(getRequestedFor(urlEqualTo("/products")));
        inventoryServiceMock.verify(2, getRequestedFor(urlMatching("/inventory/.*")));
    }

    @Test
    public void callProductGatewayWithMissingAuthorizationCode() throws Exception {

        HttpHeaders headers = new HttpHeaders();
        ResponseEntity<String> orderResponse = restTemplate.exchange("/api/products", HttpMethod.GET, new HttpEntity<>(headers), String.class);

        assertThat(orderResponse.getStatusCodeValue(), equalTo(HttpStatus.SC_UNAUTHORIZED));

        catalogServiceMock.verify(0, getRequestedFor(urlMatching("/.*")));
        inventoryServiceMock.verify(0, getRequestedFor(urlMatching(".*")));
    }

    @Test
    public void callProductGatewayWithExpiredAuthorizationCode() throws Exception {

        HttpHeaders headers = new HttpHeaders();
        String authHeader = "Bearer " + getExpiredAccessToken("coolstore");
        headers.add(HttpHeaders.AUTHORIZATION, authHeader);
        ResponseEntity<String> orderResponse = restTemplate.exchange("/api/products", HttpMethod.GET, new HttpEntity<>(headers), String.class);

        assertThat(orderResponse.getStatusCodeValue(), equalTo(HttpStatus.SC_UNAUTHORIZED));

        catalogServiceMock.verify(0, getRequestedFor(urlMatching("/.*")));
        inventoryServiceMock.verify(0, getRequestedFor(urlMatching(".*")));
    }

    @Test
    public void callProductGatewayWithWrongRoleInAuthorizationCode() throws Exception {

        HttpHeaders headers = new HttpHeaders();
        String authHeader = "Bearer " + getValidAccessToken("wrongrole");
        headers.add(HttpHeaders.AUTHORIZATION, authHeader);
        ResponseEntity<String> orderResponse = restTemplate.exchange("/api/products", HttpMethod.GET, new HttpEntity<>(headers), String.class);

        assertThat(orderResponse.getStatusCodeValue(), equalTo(HttpStatus.SC_FORBIDDEN));

        catalogServiceMock.verify(0, getRequestedFor(urlMatching("/.*")));
        inventoryServiceMock.verify(0, getRequestedFor(urlMatching(".*")));
    }

    private void adviceCamelContext() throws Exception {
        camelContext.getRouteDefinition("productRoute").adviceWith(camelContext, new AdviceWithRouteBuilder() {

            @Override
            public void configure() throws Exception {
                interceptSendToEndpoint("http4://DUMMY")
                    .process(new Processor() {

                        @Override
                        public void process(Exchange exchange) throws Exception {
                            exchange.getIn().setHeader(Exchange.HTTP_URI, "http://localhost:" + catalogServiceMock.port());
                        }
                    });
            }
        });

        camelContext.getRouteDefinition("inventoryRoute").adviceWith(camelContext, new AdviceWithRouteBuilder() {

            @Override
            public void configure() throws Exception {
                interceptSendToEndpoint("http4://DUMMY1")
                    .process(new Processor() {

                        @Override
                        public void process(Exchange exchange) throws Exception {
                            exchange.getIn().setHeader(Exchange.HTTP_URI, "http://localhost:" + inventoryServiceMock.port());
                        }
                    });
            }
        });
    }

    private void assertCorsHeaders(ResponseEntity<?> response) {
        assertThat(response.getHeaders().get("Access-Control-Allow-Origin"), notNullValue());
        assertThat(response.getHeaders().get("Access-Control-Allow-Origin").get(0), equalTo("*"));
        assertThat(response.getHeaders().get("Access-Control-Allow-Methods"), notNullValue());
        assertThat(response.getHeaders().get("Access-Control-Allow-Methods").get(0), equalTo("GET, HEAD, POST, PUT, DELETE, TRACE, OPTIONS, CONNECT, PATCH"));
    }

    private String getValidAccessToken(String role) throws Exception {
        return createAccessToken(role, (int) (System.currentTimeMillis() / 1000));
    }

    private String getExpiredAccessToken(String role) throws Exception {
        return createAccessToken(role, (int) ((System.currentTimeMillis() / 1000)-600));
    }

    private String createAccessToken(String role, int issuedAt) throws Exception {
        AccessToken token = new AccessToken();
        token.type(TokenUtil.TOKEN_TYPE_BEARER);
        token.subject("testuser");
        token.issuedAt(issuedAt);
        token.issuer("https://rhsso:8443/auth/realms/coolstore-test");
        token.expiration(issuedAt + 300);
        token.setAllowedOrigins(new HashSet<>());

        AccessToken.Access access = new AccessToken.Access();
        token.setRealmAccess(access);
        access.addRole(role);

        Algorithm jwsAlgorithm = Algorithm.RS256;
        PrivateKey privateKey = readPrivateKey();
        String encodedToken = new JWSBuilder().type("JWT").jsonContent(token).sign(jwsAlgorithm, privateKey);
        return encodedToken;
    }

    private PrivateKey readPrivateKey() throws Exception {
        Security.addProvider(new BouncyCastleProvider());
        KeyFactory factory = KeyFactory.getInstance("RSA", "BC");
        InputStream is = Thread.currentThread().getContextClassLoader().getResourceAsStream("private.pem");
        PemReader privateKeyReader = new PemReader(new InputStreamReader(is));
        try {
            PemObject privObject = privateKeyReader.readPemObject();
            PKCS8EncodedKeySpec privKeySpec = new PKCS8EncodedKeySpec(privObject.getContent());
            PrivateKey privateKey = factory.generatePrivate(privKeySpec);
            return privateKey;
        } finally {
            privateKeyReader.close();
        }
    }

}
