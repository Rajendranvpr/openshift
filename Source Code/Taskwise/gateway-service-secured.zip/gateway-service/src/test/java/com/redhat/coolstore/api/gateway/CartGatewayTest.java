package com.redhat.coolstore.api.gateway;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.delete;
import static com.github.tomakehurst.wiremock.client.WireMock.deleteRequestedFor;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.getRequestedFor;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.postRequestedFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static com.github.tomakehurst.wiremock.client.WireMock.urlMatching;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.Security;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.builder.AdviceWithRouteBuilder;
import org.apache.camel.builder.NotifyBuilder;
import org.apache.http.HttpStatus;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.util.io.pem.PemObject;
import org.bouncycastle.util.io.pem.PemReader;
import org.hamcrest.Matchers;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.keycloak.jose.jws.Algorithm;
import org.keycloak.jose.jws.JWSBuilder;
import org.keycloak.representations.AccessToken;
import org.keycloak.util.TokenUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.tomakehurst.wiremock.client.WireMock;
import com.github.tomakehurst.wiremock.core.WireMockConfiguration;
import com.github.tomakehurst.wiremock.junit.WireMockRule;
import com.redhat.coolstore.api.gateway.model.Product;
import com.redhat.coolstore.api.gateway.model.ShoppingCart;
import com.redhat.coolstore.api.gateway.model.ShoppingCartItem;

@ActiveProfiles("test")
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
public class CartGatewayTest {

    @Autowired
    private TestRestTemplate restTemplate;

    @Autowired
    private CamelContext camelContext;

    @Rule
    public WireMockRule cartServiceMock = new WireMockRule(WireMockConfiguration.wireMockConfig().dynamicPort());

    @Test
    @DirtiesContext
    public void getCart() throws Exception {

        String authHeader = "Bearer " + getValidAccessToken("coolstore");

        cartServiceMock.stubFor(get(urlEqualTo("/cart/FOO"))
                .withHeader("Authorization", WireMock.equalTo(authHeader))
                .willReturn(aResponse()
                .withStatus(200).withHeader("Content-Type", "application/json")
                .withBody(buildShoppingCartResponse())));

        NotifyBuilder notify = new NotifyBuilder(camelContext).fromRoute("getCartRoute").whenDone(1).create();

        adviceCamelContext("getCartRoute");

        HttpHeaders headers = new HttpHeaders();
        headers.add(HttpHeaders.AUTHORIZATION, authHeader);
        ResponseEntity<String> response = restTemplate.exchange("/api/cart/FOO", HttpMethod.GET, new HttpEntity<>(headers), String.class);

        assertThat(notify.matches(10, TimeUnit.SECONDS), is(true));

        assertThat(response.getStatusCodeValue(), equalTo(HttpStatus.SC_OK));

        JsonNode node = new ObjectMapper(new JsonFactory()).readTree(response.getBody());

        assertThat(node.get("shoppingCartItemList").get(0).get("product").get("itemId").asText(), equalTo("p1"));
        assertThat(node.get("cartTotal").asInt(), equalTo(20));
        assertCorsHeaders(response);
        cartServiceMock.verify(getRequestedFor(urlEqualTo("/cart/FOO")));
    }

    @Test
    public void getCartWithMissingAuthorizationCode() throws Exception {

        HttpHeaders headers = new HttpHeaders();
        ResponseEntity<String> response = restTemplate.exchange("/api/cart/FOO", HttpMethod.GET, new HttpEntity<>(headers), String.class);

        assertThat(response.getStatusCodeValue(), equalTo(HttpStatus.SC_UNAUTHORIZED));

        cartServiceMock.verify(0, getRequestedFor(urlMatching("/.*")));
    }

    @Test
    public void getCartWithExpiredAuthorizationCode() throws Exception {

        HttpHeaders headers = new HttpHeaders();
        String authHeader = "Bearer " + getExpiredAccessToken("coolstore");
        headers.add(HttpHeaders.AUTHORIZATION, authHeader);
        ResponseEntity<String> response = restTemplate.exchange("/api/cart/FOO", HttpMethod.GET, new HttpEntity<>(headers), String.class);

        assertThat(response.getStatusCodeValue(), equalTo(HttpStatus.SC_UNAUTHORIZED));

        cartServiceMock.verify(0, getRequestedFor(urlMatching("/.*")));
    }

    @Test
    public void getCartWithWrongRoleInAuthorizationCode() throws Exception {

        HttpHeaders headers = new HttpHeaders();
        String authHeader = "Bearer " + getValidAccessToken("wrongrole");
        headers.add(HttpHeaders.AUTHORIZATION, authHeader);
        ResponseEntity<String> response = restTemplate.exchange("/api/cart/FOO", HttpMethod.GET, new HttpEntity<>(headers), String.class);

        assertThat(response.getStatusCodeValue(), equalTo(HttpStatus.SC_FORBIDDEN));

        cartServiceMock.verify(0, getRequestedFor(urlMatching("/.*")));
    }

    @Test
    @DirtiesContext
    public void addToCart() throws Exception {

        String authHeader = "Bearer " + getValidAccessToken("coolstore");

        cartServiceMock.stubFor(post(urlEqualTo("/cart/FOO/p1/2"))
                .withHeader("Authorization", WireMock.equalTo(authHeader))
                .willReturn(aResponse()
                .withStatus(200).withHeader("Content-Type", "application/json")
                .withBody(buildShoppingCartResponse())));

        NotifyBuilder notify = new NotifyBuilder(camelContext).fromRoute("addToCartRoute").whenDone(1).create();

        adviceCamelContext("addToCartRoute");

        HttpHeaders headers = new HttpHeaders();
        headers.add(HttpHeaders.AUTHORIZATION, authHeader);
        ResponseEntity<String> response = restTemplate.exchange("/api/cart/FOO/p1/2", HttpMethod.POST, new HttpEntity<>(headers), String.class);

        assertThat(notify.matches(10, TimeUnit.SECONDS), is(true));

        assertThat(response.getStatusCodeValue(), equalTo(HttpStatus.SC_OK));

        JsonNode node = new ObjectMapper(new JsonFactory()).readTree(response.getBody());

        assertThat(node.get("shoppingCartItemList").get(0).get("product").get("itemId").asText(), equalTo("p1"));
        assertThat(node.get("cartTotal").asInt(), equalTo(20));
        assertCorsHeaders(response);
        cartServiceMock.verify(postRequestedFor(urlEqualTo("/cart/FOO/p1/2")));
    }

    @Test
    public void addToCartWithoutAuthenticationHeader() throws Exception {

        ResponseEntity<String> response = restTemplate.exchange("/api/cart/FOO/p1/2", HttpMethod.POST, null, String.class);
        assertThat(response.getStatusCodeValue(), equalTo(HttpStatus.SC_UNAUTHORIZED));

    }

    @Test
    public void addToCartWithExpiredAuthenticationToken() throws Exception {

        HttpHeaders headers = new HttpHeaders();
        String authHeader = "Bearer " + getExpiredAccessToken("coolstore");
        headers.add(HttpHeaders.AUTHORIZATION, authHeader);

        ResponseEntity<String> response = restTemplate.exchange("/api/cart/FOO/p1/2", HttpMethod.POST, new HttpEntity<>(headers), String.class);
        assertThat(response.getStatusCodeValue(), equalTo(HttpStatus.SC_UNAUTHORIZED));

    }

    @Test
    public void addToCartWithWrongRoleInAuthenticationToken() throws Exception {

        HttpHeaders headers = new HttpHeaders();
        String authHeader = "Bearer " + getValidAccessToken("wrongrole");
        headers.add(HttpHeaders.AUTHORIZATION, authHeader);

        ResponseEntity<String> response = restTemplate.exchange("/api/cart/FOO/p1/2", HttpMethod.POST, new HttpEntity<>(headers), String.class);
        assertThat(response.getStatusCodeValue(), equalTo(HttpStatus.SC_FORBIDDEN));

    }

    @Test
    @DirtiesContext
    public void deleteFromCart() throws Exception {

        String authHeader = "Bearer " + getValidAccessToken("coolstore");

        cartServiceMock.stubFor(delete(urlEqualTo("/cart/FOO/p1/3"))
                .withHeader("Authorization", WireMock.equalTo(authHeader))
                .willReturn(aResponse()
                .withStatus(200).withHeader("Content-Type", "application/json")
                .withBody(buildShoppingCartResponse())));

        NotifyBuilder notify = new NotifyBuilder(camelContext).fromRoute("deleteFromCartRoute").whenDone(1).create();

        adviceCamelContext("deleteFromCartRoute");

        HttpHeaders headers = new HttpHeaders();
        headers.add(HttpHeaders.AUTHORIZATION, authHeader);
        ResponseEntity<String> response = restTemplate.exchange("/api/cart/FOO/p1/3", HttpMethod.DELETE, new HttpEntity<>(headers), String.class);

        assertThat(notify.matches(10, TimeUnit.SECONDS), is(true));

        assertThat(response.getStatusCodeValue(), equalTo(HttpStatus.SC_OK));

        JsonNode node = new ObjectMapper(new JsonFactory()).readTree(response.getBody());

        assertThat(node.get("shoppingCartItemList").get(0).get("product").get("itemId").asText(), equalTo("p1"));
        assertThat(node.get("cartTotal").asInt(), equalTo(20));
        assertCorsHeaders(response);
        cartServiceMock.verify(deleteRequestedFor(urlEqualTo("/cart/FOO/p1/3")));
    }

    @Test
    public void deleteFromCartWithoutAuthenticationHeader() throws Exception {

        ResponseEntity<String> response = restTemplate.exchange("/api/cart/FOO/p1/3",HttpMethod.DELETE, null, String.class);
        assertThat(response.getStatusCodeValue(), equalTo(HttpStatus.SC_UNAUTHORIZED));
    }

    @Test
    public void deleteFromCartWithExpiredAuthenticationToken() throws Exception {

        HttpHeaders headers = new HttpHeaders();
        String authHeader = "Bearer " + getExpiredAccessToken("coolstore");
        headers.add(HttpHeaders.AUTHORIZATION, authHeader);

        ResponseEntity<String> response = restTemplate.exchange("/api/cart/FOO/p1/3",HttpMethod.DELETE, new HttpEntity<>(headers), String.class);
        assertThat(response.getStatusCodeValue(), equalTo(HttpStatus.SC_UNAUTHORIZED));
    }

    @Test
    public void deleteFromCartWithWrongRoleInAuthenticationToken() throws Exception {

        HttpHeaders headers = new HttpHeaders();
        String authHeader = "Bearer " + getValidAccessToken("wrongrole");
        headers.add(HttpHeaders.AUTHORIZATION, authHeader);

        ResponseEntity<String> response = restTemplate.exchange("/api/cart/FOO/p1/3",HttpMethod.DELETE, new HttpEntity<>(headers), String.class);
        assertThat(response.getStatusCodeValue(), equalTo(HttpStatus.SC_FORBIDDEN));
    }

    @Test
    @DirtiesContext
    public void checkoutCart() throws Exception {

        ObjectMapper mapper = new ObjectMapper();
        ShoppingCart cart = new ShoppingCart();
        String cartResponseStr = mapper.writeValueAsString(cart);

        String authHeader = "Bearer " + getValidAccessToken("coolstore");

        cartServiceMock.stubFor(post(urlEqualTo("/cart/checkout/FOO"))
                .withHeader("Authorization", WireMock.equalTo(authHeader))
                .willReturn(aResponse()
                .withStatus(200).withHeader("Content-Type", "application/json")
                .withBody(cartResponseStr)));

        NotifyBuilder notify = new NotifyBuilder(camelContext).fromRoute("checkoutRoute").whenDone(1).create();

        adviceCamelContext("checkoutRoute");

        HttpHeaders headers = new HttpHeaders();
        headers.add(HttpHeaders.AUTHORIZATION, authHeader);
        ResponseEntity<String> response = restTemplate.exchange("/api/cart/checkout/FOO", HttpMethod.POST, new HttpEntity<>(headers), String.class);

        assertThat(notify.matches(10, TimeUnit.SECONDS), is(true));

        assertThat(response.getStatusCodeValue(), equalTo(HttpStatus.SC_OK));

        JsonNode node = new ObjectMapper(new JsonFactory()).readTree(response.getBody());

        assertThat(node.get("shoppingCartItemList").has(0), Matchers.is(false));
        assertThat(node.get("cartTotal").asInt(), equalTo(0));
        assertCorsHeaders(response);
        cartServiceMock.verify(postRequestedFor(urlEqualTo("/cart/checkout/FOO")));
    }

    @Test
    public void checkoutCartWithoutAuthenticationHeader() throws Exception {

        ResponseEntity<String> response = restTemplate.exchange("/api/cart/checkout/FOO", HttpMethod.POST, null, String.class);
        assertThat(response.getStatusCodeValue(), equalTo(HttpStatus.SC_UNAUTHORIZED));
    }

    @Test
    public void checkoutCartWithExpiredAuthenticationToken() throws Exception {

        HttpHeaders headers = new HttpHeaders();
        String authHeader = "Bearer " + getExpiredAccessToken("coolstore");
        headers.add(HttpHeaders.AUTHORIZATION, authHeader);

        ResponseEntity<String> response = restTemplate.exchange("/api/cart/checkout/FOO", HttpMethod.POST, new HttpEntity<>(headers), String.class);
        assertThat(response.getStatusCodeValue(), equalTo(HttpStatus.SC_UNAUTHORIZED));
    }

    @Test
    public void checkoutCartWithWrongRoleAuthenticationToken() throws Exception {

        HttpHeaders headers = new HttpHeaders();
        String authHeader = "Bearer " + getValidAccessToken("wrongrole");
        headers.add(HttpHeaders.AUTHORIZATION, authHeader);

        ResponseEntity<String> response = restTemplate.exchange("/api/cart/checkout/FOO", HttpMethod.POST, new HttpEntity<>(headers), String.class);
        assertThat(response.getStatusCodeValue(), equalTo(HttpStatus.SC_FORBIDDEN));
    }

    @Test
    @DirtiesContext
    public void optionsRequest() throws Exception {

        NotifyBuilder notify = new NotifyBuilder(camelContext).whenDone(1).create();

        ResponseEntity<String> response = restTemplate.exchange("/api/cart/FOO/p1/3",HttpMethod.OPTIONS, null, String.class);
        assertThat(response.getStatusCodeValue(), equalTo(HttpStatus.SC_OK));
        assertCorsHeaders(response);
        assertThat(notify.matches(10, TimeUnit.SECONDS), is(true));
    }

    private String buildShoppingCartResponse() throws Exception{
        ObjectMapper mapper = new ObjectMapper();
        ShoppingCart cart = new ShoppingCart();
        Product product = new Product();
        product.setItemId("p1");
        product.setDesc("Test Product Description");
        product.setName("Test Product");
        product.setPrice(10.0);
        product.setAvailability(null);
        ShoppingCartItem item = new ShoppingCartItem();
        item.setProduct(product);
        item.setQuantity(2);
        item.setPromoSavings(5.0);
        item.setPrice(product.getPrice()*item.getQuantity());
        List<ShoppingCartItem> items = new ArrayList<ShoppingCartItem>();
        items.add(item);
        cart.setId("FOO");
        cart.setShoppingCartItemList(items);
        cart.setCartItemTotal(20);
        cart.setCartItemPromoSavings(5.0);
        cart.setShippingTotal(0);
        cart.setShippingPromoSavings(0);
        cart.setCartTotal(20);
        return mapper.writeValueAsString(cart);
    }

    private void adviceCamelContext(String route) throws Exception{
        camelContext.getRouteDefinition(route).adviceWith(camelContext, new AdviceWithRouteBuilder() {

            @Override
            public void configure() throws Exception {
                interceptSendToEndpoint("http4://DUMMY")
                    .process(new Processor() {

                        @Override
                        public void process(Exchange exchange) throws Exception {
                            exchange.getIn().setHeader(Exchange.HTTP_URI, "http://localhost:" + cartServiceMock.port());
                        }
                    });
            }
        });
    }

    private void assertCorsHeaders(ResponseEntity<?> response) {
        assertThat(response.getHeaders().get("Access-Control-Allow-Origin"), notNullValue());
        assertThat(response.getHeaders().get("Access-Control-Allow-Origin").get(0), equalTo("*"));
        assertThat(response.getHeaders().get("Access-Control-Allow-Methods"), notNullValue());
        assertThat(response.getHeaders().get("Access-Control-Allow-Methods").get(0), equalTo("GET, HEAD, POST, PUT, DELETE, TRACE, OPTIONS, CONNECT, PATCH"));
    }

    private String getValidAccessToken(String role) throws Exception {
        return createAccessToken(role, (int) (System.currentTimeMillis() / 1000));
    }

    private String getExpiredAccessToken(String role) throws Exception {
        return createAccessToken(role, (int) ((System.currentTimeMillis() / 1000)-600));
    }

    private String createAccessToken(String role, int issuedAt) throws Exception {
        AccessToken token = new AccessToken();
        token.type(TokenUtil.TOKEN_TYPE_BEARER);
        token.subject("testuser");
        token.issuedAt(issuedAt);
        token.issuer("https://rhsso:8443/auth/realms/coolstore-test");
        token.expiration(issuedAt + 300);
        token.setAllowedOrigins(new HashSet<>());

        AccessToken.Access access = new AccessToken.Access();
        token.setRealmAccess(access);
        access.addRole(role);

        Algorithm jwsAlgorithm = Algorithm.RS256;
        PrivateKey privateKey = readPrivateKey();
        String encodedToken = new JWSBuilder().type("JWT").jsonContent(token).sign(jwsAlgorithm, privateKey);
        return encodedToken;
    }

    private PrivateKey readPrivateKey() throws Exception {
        Security.addProvider(new BouncyCastleProvider());
        KeyFactory factory = KeyFactory.getInstance("RSA", "BC");
        InputStream is = Thread.currentThread().getContextClassLoader().getResourceAsStream("private.pem");
        PemReader privateKeyReader = new PemReader(new InputStreamReader(is));
        try {
            PemObject privObject = privateKeyReader.readPemObject();
            PKCS8EncodedKeySpec privKeySpec = new PKCS8EncodedKeySpec(privObject.getContent());
            PrivateKey privateKey = factory.generatePrivate(privKeySpec);
            return privateKey;
        } finally {
            privateKeyReader.close();
        }
    }
}
