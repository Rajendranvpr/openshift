package com.redhat.coolstore.cart.service;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.redhat.coolstore.cart.model.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

@Component
public class CatalogServiceImpl implements CatalogService {

    @Autowired
    RestTemplate restTemplate;

    @Value("${catalog-service.service.name}")
    private String catalogServiceUrl;

    @Override
    @HystrixCommand(groupKey = "CartService", commandKey = "CatalogService", fallbackMethod = "getFallbackProduct")
    public Product getProduct(String itemId) {

        ResponseEntity<Product> entity;
        try {
            entity = restTemplate.getForEntity("http://"+ catalogServiceUrl + "/product/" + itemId, Product.class);
            return entity.getBody();
        } catch (HttpClientErrorException e) {
            if (e.getRawStatusCode() == 404) {
                return null;
            } else {
                throw e;
            }
        }
    }

    protected Product getFallbackProduct(String itemId) {
        return null;
    }

}
